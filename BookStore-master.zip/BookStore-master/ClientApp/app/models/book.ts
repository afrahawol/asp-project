﻿export class Book {
    bookId: number;
    title: string;
    author: string;
    price: number;
}